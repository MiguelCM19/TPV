<footer class="fixed h-14 w-full bottom-0  bg-gray-900 text-clip lg:text-left mt-96">
      
        <div class="text-white text-center p-4 ">Miguel Sex Shop © 2022 Copyright</div>
    
    </footer>
</body>
</html>