<?php
$servername = "localhost";
$database = "sexshop";
$username = "root";
$password = "";


// Create connection
$conexion = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}


?>